package com.springbootapp.springbootcallingexternalapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCallingExternalApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
